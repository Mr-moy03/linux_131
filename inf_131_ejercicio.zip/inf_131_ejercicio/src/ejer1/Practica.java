package ejer1;

public class Practica { 
	private String fecha;
	private String nom;
	private int nota;
	public Practica(String fecha, String nom,int nota) {
		this.setFecha(fecha);
		this.setNom(nom); 
		this.setNota(nota);
		
	}
	public String getFecha() {
		return fecha;
	}
	public void setFecha(String fecha) {
		this.fecha = fecha;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public int getNota() {
		return nota;
	}
	public void setNota(int nota) {
		this.nota = nota;
	}
	
	@Override
	public String toString() {
		return String.format("->Fecha: %s, Nombre: %s, Nota; %d",getFecha(),getNom(),getNota());
	}
	public void mostrar() {
		System.out.println(toString());
	}

}
