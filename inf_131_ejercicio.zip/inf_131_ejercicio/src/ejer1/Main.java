package ejer1;

public class Main {
	public static void main(String [] args) {
		
		//Practicas
		Practica p1 = new Practica("12/01/2025", "Juan", 51);
		Practica p2 = new Practica("15/02/2025", "Ana", 78);
		Practica p3 = new Practica("20/03/2025", "Luis", 90);
		Practica p4 = new Practica("05/04/2025", "Valentina", 65);
		Practica p5 = new Practica("12/05/2025", "Pedro", 82);
		Practica p6 = new Practica("18/06/2025", "Valentina", 95);
		Practica p7 = new Practica("22/07/2025", "Miguel", 70);
		Practica p8 = new Practica("30/08/2025", "Lucía", 88);
		Practica p9 = new Practica("10/09/2025", "Diego", 60);
		Practica p10 = new Practica("25/10/2025", "Juan", 77);
		
		//cola Circular
		ColaCirPrac c1 = new ColaCirPrac();
		ColaCirPrac c2 = new ColaCirPrac();
		ColaCirPrac c3 = new ColaCirPrac();
		ColaCirPrac c4 = new ColaCirPrac();
		
		//Pila CC
		PilaCCPrac pl1 = new PilaCCPrac();
		
		//push
		//cola1
		c1.push(p1);
		c1.push(p4);
		c1.push(p5);
		c1.push(p7);
		
		//cola2
		c2.push(p2);
		c2.push(p6);
		c2.push(p8);
		c2.push(p5);
		c2.push(p7);
		
		//cola3
		c3.push(p1);
		c3.push(p9);
		c3.push(p10);
		c3.push(p2);
		c3.push(p7);
		
		//cola4
		c4.push(p5);
		c4.push(p6);
		c4.push(p2);
		c4.push(p7);
		
		//c1.mostrar();
		
		//push pila
		pl1.push(c1);
		pl1.push(c2);
		pl1.push(c3);
		pl1.push(c4);
		
		pl1.mostrar();
		
		System.out.println("_A)_");
		//cuantas practicas tiene cada cola
		cuantasPracticasCC(pl1);
		
		System.out.println("_B)_");
		//mostrar las practicas del estudiante x 
		xEstudiantePracticasCC(pl1,"Valentina");
		
		System.out.println("_C)_");
		//Llevar las practicas del estudiante x a una nueva cola
		ColaCirPrac colaNueva = xEstudianteNuevaColaCC(pl1,"Juan");
		colaNueva.mostrar();
		
		System.out.println("_D)_");
		//Cuantas colas tiene k Praticas
		System.out.println(cuantasColasTienenKPracticas(pl1,4));
		
		System.out.println("_E)_");
		//Mostrar las nmotas mas altas de cada cola
		//nNotasMasAltasPorCola(pl1, 2);
		notaMasAltaPorCola(pl1);
		
		
		
		
		
		
		
	}
	public static void cuantasPracticasCC(PilaCCPrac p) {
		PilaCCPrac aux1 = new PilaCCPrac();
		while(!p.esVacia()) {
			ColaCirPrac elem = p.pop();
			int cont = 0;
			ColaCirPrac aux2 = new ColaCirPrac();
			while(!elem.esVacia()) {
				Practica x = elem.pop();
				cont ++;
				aux2.push(x);
				
			}
			System.out.println(cont);
			//cont = 0;
			elem.vaciar(aux2);
			
			aux1.push(elem);
			
		}
		p.vaciar(aux1);
		
	}
	
	public static void xEstudiantePracticasCC(PilaCCPrac p,String nom) {
		PilaCCPrac aux1 = new PilaCCPrac();
		while(!p.esVacia()) {
			ColaCirPrac elem = p.pop();
			ColaCirPrac aux2 = new ColaCirPrac();
			while(!elem.esVacia()) {
				Practica x = elem.pop();
				if (x.getNom().equals(nom)) {
					x.mostrar();
				}
				aux2.push(x);
			}
			elem.vaciar(aux2);
			aux1.push(elem);
			
		}
		p.vaciar(aux1);
		
	}
	public static ColaCirPrac xEstudianteNuevaColaCC(PilaCCPrac p, String nom) {
	    PilaCCPrac aux1 = new PilaCCPrac();
	    ColaCirPrac nuevaCola = new ColaCirPrac();
	    
	    while(!p.esVacia()) {
	        ColaCirPrac elem = p.pop();
	        ColaCirPrac aux2 = new ColaCirPrac();
	        
	        while(!elem.esVacia()) {
	            Practica x = elem.pop();
	            if (x.getNom().equals(nom)) {
	                nuevaCola.push(x);
	            } else {
	                aux2.push(x);
	            }
	        }
	        elem.vaciar(aux2);
	        aux1.push(elem);
	    }
	    p.vaciar(aux1);
	    return nuevaCola;
	}
	
	public static int cuantasColasTienenKPracticas(PilaCCPrac p, int k) {
		PilaCCPrac aux1 = new PilaCCPrac();
	    int contador = 0;
	    
	    while(!p.esVacia()) {
	        ColaCirPrac elem = p.pop();
	        int contPracticas = elem.nroElem();
	        
	        if (contPracticas == k) {
	            contador++;
	        }
	        aux1.push(elem);
	    }
	    p.vaciar(aux1);
	    return contador;
	}
	/*
	public static void nNotasMasAltasPorCola(PilaCCPrac p, int n) {
	    PilaCCPrac aux1 = new PilaCCPrac();
	    int colaNumero = 1;
	    
	    while(!p.esVacia()) {
	        ColaCirPrac elem = p.pop();
	        ColaCirPrac aux2 = new ColaCirPrac();
	        
	        System.out.println("Cola " + colaNumero + ":");
	        
	        // Crear arreglo para ordenar las notas
	        int[] notas = new int[elem.nroElem()];
	        int index = 0;
	        
	        // Extraer todas las prácticas y guardar las notas
	        while(!elem.esVacia()) {
	            Practica x = elem.pop();
	            notas[index++] = x.getNota();
	            aux2.push(x);
	        }
	        elem.vaciar(aux2);
	        
	        // Ordenar las notas de mayor a menor (bubble sort)
	        for (int i = 0; i < notas.length - 1; i++) {
	            for (int j = 0; j < notas.length - i - 1; j++) {
	                if (notas[j] < notas[j + 1]) {
	                    int temp = notas[j];
	                    notas[j] = notas[j + 1];
	                    notas[j + 1] = temp;
	                }
	            }
	        }
	        
	        // Mostrar las n notas más altas
	        int mostrarHasta = Math.min(n, notas.length);
	        for (int i = 0; i < mostrarHasta; i++) {
	            System.out.println("Nota " + (i + 1) + ": " + notas[i]);
	        }
	        System.out.println("----------------");
	        
	        colaNumero++;
	        aux1.push(elem);
	    }
	    p.vaciar(aux1);
	}*/
	
	public static void notaMasAltaPorCola(PilaCCPrac p) {
	    PilaCCPrac aux1 = new PilaCCPrac();
	    int colaNumero = 1;
	    
	    while(!p.esVacia()) {
	        ColaCirPrac elem = p.pop();
	        ColaCirPrac aux2 = new ColaCirPrac();
	        int notaMasAlta = -1;  
	        
	        while(!elem.esVacia()) {
	            Practica x = elem.pop();
	            if (x.getNota() > notaMasAlta) {
	                notaMasAlta = x.getNota(); 
	            }
	            aux2.push(x);
	        }
	        elem.vaciar(aux2);

	        System.out.println("Cola " + colaNumero + ": Nota más alta = " + notaMasAlta);
	        
	        colaNumero++;
	        aux1.push(elem);
	    }
	    p.vaciar(aux1);
	}
	
	

}
