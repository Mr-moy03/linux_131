package ejer1;

import java.util.Scanner;


public class PilaCCPrac {
	private int tope;
	private int max = 50;
	private ColaCirPrac[] v = new ColaCirPrac[max];
	
	public PilaCCPrac() {
		this.tope = -1;
	}
	
	public boolean esVacia() {
		return (this.tope == -1);
	}
	
    public boolean esLlena(){
        return (this.tope == max - 1);
    }

    public void push(ColaCirPrac elem){
        if(!esLlena()){
            this.tope++;
            v[tope] = elem;
        }
        else{
            System.out.println("Pila llena");
        }
    }

    public ColaCirPrac pop(){
    	ColaCirPrac elem;
        if(!esVacia()){
            elem = v[tope];
            tope--;
            return elem;
        }else{
            System.out.println("Pila Vacia");
            return null;
        }
    }

    public int nroElem(){
        return tope + 1;
    }

    public int nroElem2(){
        PilaCCPrac aux = new PilaCCPrac();
        int c = 0;
        while(!esVacia()){
            aux.push(pop());
            c++;
        }
        vaciar(aux);
        return c;
    }

    public void vaciar(PilaCCPrac p){
        while(!p.esVacia()){
            push(p.pop());
        }
    }
/*
    public void llenar(int n){
        Scanner sc = new Scanner(System.in);
        for (int i=0;i<n;i++){
            String x = sc.nextLine();
            push(x);
        }
    }*/

    public void mostrar(){
        PilaCCPrac aux = new PilaCCPrac();
        while(!esVacia()){
        	ColaCirPrac x = pop();
            //System.out.println(x);
        	x.mostrar();
            aux.push(x);
        }
        vaciar(aux);
    }
	

}
