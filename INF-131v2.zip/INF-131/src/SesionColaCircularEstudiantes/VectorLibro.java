package SesionColaCircularEstudiantes;


public class VectorLibro {
    protected int MAX = 50;
    protected Libro[] v = new Libro[MAX];
}
