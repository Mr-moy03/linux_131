package SesionColaCircularEstudiantes;

public class Principal {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        ColaCircularEst z = new ColaCircularEst();
        System.out.println(z.nroElem());

        Libro l1 = new Libro("php", 100);
        Libro l2 = new Libro("html", 50);
        Libro l3 = new Libro("java", 110);
        Libro l4 = new Libro("go", 30);
        Libro l5 = new Libro("JavaScript", 100);
        Libro l6 = new Libro("pyhton", 500);

        PilaLibro pl1 = new PilaLibro();
        pl1.push(l1);
        pl1.push(l2);
        pl1.push(l3);

        PilaLibro pl2 = new PilaLibro();
        pl2.push(l4);
        pl2.push(l5);
        pl2.push(l6);

        PilaLibro pl3 = new PilaLibro();
        pl3.push(l1);
        pl3.push(l3);
        pl3.push(l5);

        Estudiante e1 = new Estudiante("Alan Brito", pl1);
        Estudiante e2 = new Estudiante("Esteban Dido", pl2);
        Estudiante e3 = new Estudiante("Isabel Patty", pl3);

        z.push(e1);
        z.push(e2);
        z.push(e3);

        z.mostrar();

        //b)
        System.out.println("\n---------------");
        mostrarLibroEstduiante(z, l3);


//		z.llenar(10);
//
//		z.adi(50);
//		z.adi(20);
//		z.adi(30);
//		z.adi(10);
//		z.adi(40);
//
//		z.mostrar();
//
//		System.out.println("\nNro de elementos: " + z.nroElem());
//		z.eli();
//		z.eli();
//		System.out.println("\nNro de elementos: " + z.nroElem());
//		z.mostrar();
//
//

    }

    static void mostrarLibroEstduiante(ColaCircularEst c, Libro lib) {
        int ne = c.nroElem();
        for (int i = 1; i <= ne; i++) {
            Estudiante x = c.pop();
            if(buscarLibro(x,lib))
                System.out.println("nombre estudiante: " +x.getNom());
            c.push(x);
        }
    }
    static boolean buscarLibro(Estudiante e, Libro lib) {
        PilaLibro aux = new PilaLibro();
        boolean sw = false;
        while(!e.getPl().esVacia()) {
            Libro x = e.getPl().pop();
            if(x.getTitulo().equals(lib.getTitulo()) &&
                    x.getNroPag() == lib.getNroPag())
                sw = true;
            aux.push(x);
        }
        e.getPl().vaciar(aux);
        return sw;
    }
}
