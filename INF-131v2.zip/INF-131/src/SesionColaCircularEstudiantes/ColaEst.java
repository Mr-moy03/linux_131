package SesionColaCircularEstudiantes;

public class ColaEst extends VectorEst{
    protected int fr;
    protected int fi;

    public ColaEst() {
        this.fr = 0;
        this.fi = 0;
    }
}