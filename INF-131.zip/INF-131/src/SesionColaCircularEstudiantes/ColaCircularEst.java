package SesionColaCircularEstudiantes;

public class ColaCircularEst extends ColaEst{
    public ColaCircularEst() {
        super();
    }
    public int nroElem() {
        return (fi - fr + MAX) % MAX;
    }
    public boolean esVacia() {
        if(nroElem() == 0)
            return true;
        return false;

    }
    public boolean esLlena() {
        if(nroElem() == MAX-1)
            return true;
        return false;
    }
    public void push(Estudiante elem) {
        if(!esLlena()) {
            fi = (fi + 1) % MAX;
            v[fi] = elem;
        }else
            System.out.println("cola circular llena!!!");
    }
    public Estudiante pop() {
        Estudiante elem;
        if(!esVacia()) {
            fr = (fr + 1) % MAX;
            elem = v[fr];
            return elem;
        }else {
            System.out.println("Cola circular vacia!!");
            return null;
        }
    }

    public void vaciar(ColaCircularEst z) {
        while(!z.esVacia()) {
            push(z.pop());
        }
    }

    public void mostrar() {
        ColaCircularEst aux = new ColaCircularEst();
        while(!esVacia()) {
            Estudiante elem = pop();
            //System.out.print("");
            elem.mostrar();
            aux.push(elem);
        }
        vaciar(aux);
    }
}
