package SesionColaCircularEstudiantes;


public class VectorEst {
    protected int MAX = 50;
    protected Estudiante[] v = new Estudiante[MAX];
}
