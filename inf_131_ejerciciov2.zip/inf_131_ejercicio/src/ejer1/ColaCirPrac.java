package ejer1;

public class ColaCirPrac {
	private int max = 50;
	private Practica[] v = new Practica[max];
	private int fr;
	private int fi;
	
	public ColaCirPrac() {
		this.fr = 0;
		this.fi = 0;

	}
	
	public int nroElem() {
        return (fi - fr + max) % max;
    }
	
    public boolean esVacia() {
    	return (nroElem() == 0);
    }
    
    public boolean esLlena() {
    	return(nroElem() == max - 1);
    }
    
    public void push(Practica elem) {
        if(!esLlena()) {
            fi = (fi + 1) % max ;
            v[fi] = elem;
        }else
            System.out.println("cola circular llena!!!");
    }
    public Practica pop() {
        Practica elem;
        if(!esVacia()) {
            fr = (fr + 1) % max;
            elem = v[fr];
            return elem;
        }else {
            System.out.println("Cola circular vacia!!");
            return null;
        }
    }

    public void vaciar(ColaCirPrac z) {
        while(!z.esVacia()) {
            push(z.pop());
        }
    }

    public void mostrar() {
    	ColaCirPrac aux = new ColaCirPrac();
    	System.out.println("______________");
        while(!esVacia()) {
            Practica elem = pop();
            elem.mostrar();
            aux.push(elem);
        }
        System.out.println("______________");
        vaciar(aux);
    }

}
